document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("myName").addEventListener("click", function () {
    chrome.tabs.create({ url: "https://codeforces.com/profile/nhan0123456" });
  });
});
